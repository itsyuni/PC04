<?php
namespace app\forms;

use std, gui, framework, app;


class win10edge extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
