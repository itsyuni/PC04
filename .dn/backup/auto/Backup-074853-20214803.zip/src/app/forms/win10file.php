<?php
namespace app\forms;

use std, gui, framework, app;


class win10file extends AbstractForm
{

    /**
     * @event image.click-Left 
     */
    function doImageClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event rect.click-Left 
     */
    function doRectClickLeft(UXMouseEvent $e = null)
    {    
        
    }

}
